# TRYxDEVIL Mod (Fabric, Minecraft 1.21.10)

Client-side Fabric mod that displays a welcome notification for six seconds when entering a single-player world or joining a multiplayer server.

Message:
- TRYxDEVIL Mod
- Hello, thanks for downloading
- TRYxDEVIL mod

## Get a compiled JAR without writing code

This project includes a GitHub Actions workflow that builds the mod automatically.

1. Create a new repository on GitHub.
2. Upload the contents of this project into the repository (including the hidden `.github` folder).
3. Open the repository's **Actions** tab and select **Build TRYxDEVIL Mod**.
4. When the workflow finishes successfully, open that run and download the artifact named `TRYxDEVIL-Mod-1.21.10-Fabric`.
5. Extract the downloaded artifact ZIP. Put the `.jar` inside your Minecraft `mods` folder.

The build requires internet access on GitHub's build runner to download Gradle and Fabric dependencies. The artifact ZIP is not itself the mod; extract it to get the JAR.

## Requirements

- Minecraft Java Edition 1.21.10
- Fabric Loader for 1.21.10
- Fabric API matching Minecraft 1.21.10
- Java 21 is used by the build environment
