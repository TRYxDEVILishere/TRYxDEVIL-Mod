package com.tryxdevil.mod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientWorldEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;

public final class TRYxDEVILMod implements ClientModInitializer {
    private static final long DISPLAY_DURATION_MS = 6_000L;
    private static final String TITLE = "TRYxDEVIL Mod";
    private static final String LINE_1 = "Hello, thanks for downloading";
    private static final String LINE_2 = "TRYxDEVIL mod";

    private static volatile long visibleUntil = 0L;

    @Override
    public void onInitializeClient() {
        // Multiplayer: show the notification when the client joins a server.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> showNotification());

        // Single-player and world changes: show it after entering a client world.
        ClientWorldEvents.AFTER_CLIENT_WORLD_CHANGE.register((client, world) -> {
            if (world != null) {
                showNotification();
            }
        });

        HudRenderCallback.EVENT.register(TRYxDEVILMod::renderNotification);
    }

    private static void showNotification() {
        visibleUntil = System.currentTimeMillis() + DISPLAY_DURATION_MS;
    }

    private static void renderNotification(DrawContext context, net.minecraft.client.render.RenderTickCounter tickCounter) {
        if (System.currentTimeMillis() > visibleUntil) {
            return;
        }

        MinecraftClient client = MinecraftClient.getInstance();
        if (client == null || client.textRenderer == null) {
            return;
        }

        int padding = 8;
        int titleWidth = client.textRenderer.getWidth(TITLE);
        int line1Width = client.textRenderer.getWidth(LINE_1);
        int line2Width = client.textRenderer.getWidth(LINE_2);
        int boxWidth = Math.max(titleWidth, Math.max(line1Width, line2Width)) + padding * 2;
        int boxHeight = 46;

        // Position it on the right-hand side, below the top edge.
        int x = context.getScaledWindowWidth() - boxWidth - 12;
        int y = Math.max(12, context.getScaledWindowHeight() / 4);

        // Semi-transparent dark background, like a compact in-game toast.
        context.fill(x, y, x + boxWidth, y + boxHeight, 0xC8202020);
        context.fill(x, y, x + 3, y + boxHeight, 0xFF55FF55);
        context.drawText(client.textRenderer, Text.literal(TITLE), x + padding, y + 5, 0xFF55FF55, false);
        context.drawText(client.textRenderer, Text.literal(LINE_1), x + padding, y + 19, 0xFFFFFFFF, false);
        context.drawText(client.textRenderer, Text.literal(LINE_2), x + padding, y + 31, 0xFFFFFFFF, false);
    }
}
